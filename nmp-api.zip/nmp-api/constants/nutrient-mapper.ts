export const NutrientsMapper = {
  0: 'N',
  1: 'P2O5',
  2: 'K2O',
  3: 'MgO',
  4: 'Na2O',
  5: 'SO3',
  6: 'Lime',
};
