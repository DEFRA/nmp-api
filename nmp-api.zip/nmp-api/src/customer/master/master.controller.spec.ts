// import { Test, TestingModule } from '@nestjs/testing';
// import { MasterController } from './master.controller';
// import { MasterService } from './master.service';

describe('MasterController', () => {
  // let controller: MasterController;
  // beforeEach(async () => {
  //   const app: TestingModule = await Test.createTestingModule({
  //     controllers: [MasterController],
  //     providers: [MasterService],
  //   }).compile();
  //   controller = app.get<MasterController>(MasterController);
  // });
  // describe('getAll', () => {
  //   it('should return', async () => {
  //     const result = await controller.getAll();
  //     expect(result.records).toBeTruthy();
  //   });
  // });

  describe('master controller test', () => {
    it('truthy', () => {
      expect(true).toBeTruthy();
    });
  });
});
